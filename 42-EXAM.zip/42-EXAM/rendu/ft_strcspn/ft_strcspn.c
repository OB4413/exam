#include <stdlib.h>

size_t	ft_strcspn(const char *s, const char *reject)
{
    int i = 0;
    int j = 0;
    while(s[i])
    {
        while(reject[j])
        {
            if(s[i] == reject[j])
                return i;
            j++;
        }
        j = 0;
        i++;
    }
    return i;
}

// #include <string.h>
// #include <stdio.h>

// int main()
// {
//     char str[] = "test";
//     char str2[] = "f";
//     printf("%lu\n",strcspn(str,str2));
//     printf("%lu\n",ft_strcspn(str,str2));
// }